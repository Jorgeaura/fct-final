from flask import render_template, session, url_for, flash, redirect, request, render_template_string, jsonify
from flask_login import login_user
from loja import app, db, login_manager, bcrypt
from loja.admin.forms import RegistrationForm, LoginForm
from loja.admin.models import Utilizador, Cliente
from loja.produtos.models import Produto
from functools import wraps
from flask_login import current_user
from datetime import date
from loja.carrinho.models import LinhaEncomenda, Encomenda


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:   
            flash('Por favor, faça o login para acessar esta página.', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_user(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.roleId == 1:
            flash('Nao tem permissao para acessar esta página.', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def client_user(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.roleId == 2:
            flash('Nao tem permissao para acessar esta página.', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@login_manager.user_loader
def load_user(user_id):
    return Utilizador.query.get(int(user_id))


def already_login(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if current_user.is_authenticated:
            if current_user.roleId == 1:
                return redirect(url_for('admin'))
            elif current_user.roleId == 2:
                return redirect(url_for('home'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def layout():
    return render_template("layout.html")



@app.route('/home')
@client_user
@login_required
def home():
        return render_template('cliente/home.html')


@app.route('/admin')
@login_required
@admin_user
def admin():
    produtos = Produto.query.all()
    return render_template("admin/index.html", produtos=produtos)


@app.route('/registar', methods=['GET', 'POST'])
@already_login
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        email = form.email.data
        nome = form.nome.data
        morada = form.morada.data 
        hashed_password = bcrypt.generate_password_hash(form.password.data)

        existing_user = Utilizador.query.filter_by(email=email).first()
        if existing_user:
            flash('Email já está em uso. Por favor, escolha outro.', 'error')
            return redirect(url_for('register'))

        novo_utilizador = Utilizador(email=email, password=hashed_password, roleId=2)
        db.session.add(novo_utilizador)
        db.session.commit()

        novo_cliente = Cliente(nome=nome, morada=morada, utilizadorId=novo_utilizador.id)
        db.session.add(novo_cliente)
        db.session.commit()

        flash('Registo bem-sucedido! Faça o login para continuar.', 'success')
        return redirect(url_for('login'))
    return render_template('admin/registar.html', form=form)


@app.route('/login', methods=['GET', 'POST'])
@already_login
def login():
    form = LoginForm()

    if form.validate_on_submit():
        email = form.email.data

        utilizador = Utilizador.query.filter_by(email=email).first()

        if utilizador and bcrypt.check_password_hash(utilizador.password, form.password.data):
            login_user(utilizador)
            if utilizador.roleId == 1:
                return redirect(url_for('admin')) 
            else:
                return redirect(url_for('home')) 
        else:
            flash('Email não encontrado ou senha incorreta. Por favor, tente novamente.', 'danger')
    return render_template('admin/login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    session.clear()
    return redirect(url_for('layout'))




@app.route('/removecliente/<int:id>', methods=['POST'])
@login_required
@admin_user
def removecliente(id):
    cliente = Cliente.query.get_or_404(id)
    utilizador = Utilizador.query.filter_by(id=cliente.utilizadorId).first()
    if utilizador:
        db.session.delete(utilizador)
    db.session.delete(cliente)
    db.session.commit()
    flash(f'{cliente.nome} removido com sucesso', 'success')  
    return redirect(url_for('clientes'))



@app.route("/clientes")
@admin_user
@login_required
def clientes():
    clientes = Cliente.query.all()
    return render_template('cliente/clientes.html', clientes=clientes)


